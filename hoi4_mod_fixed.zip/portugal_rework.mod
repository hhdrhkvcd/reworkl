version="1.0"
tags={
    "National Focuses"
    "Gameplay"
}
name="Iberian Renewal"
path="mod/portugal_rework"
supported_version="1.19.*"
