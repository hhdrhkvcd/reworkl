version="1.0"
tags={
    "National Focuses"
    "Gameplay"
}
name="Iberian Renewal"
supported_version="1.19.*"
